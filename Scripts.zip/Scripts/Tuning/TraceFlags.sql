--Muda a visualização do plano de execução, onde podemos visualizar o seek e o predicate separados como FILTER
OPTION(RECOMPILE, QueryTraceON 9130)