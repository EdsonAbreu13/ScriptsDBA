
select name,log_reuse_wait_descFrom sys.databases


sp_removedbreplication 'nome do banco'

